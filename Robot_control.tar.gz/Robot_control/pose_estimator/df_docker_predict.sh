#!/bin/bash
sudo docker exec df_test bash /home/DenseFusion/predict_img.sh